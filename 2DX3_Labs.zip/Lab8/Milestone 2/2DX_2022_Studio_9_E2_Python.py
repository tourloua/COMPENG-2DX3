import serial
import math
import matplotlib.pyplot as plt

# Initialize the serial port
s = serial.Serial(port='COM3', baudrate=115200, timeout=10)
print("Opening: " + s.name)

data = []

# Reset the buffers of the UART port to delete the remaining data in the buffers
s.reset_output_buffer()
s.reset_input_buffer()

# Wait for the user's signal to start the program



# Send the character 's' to MCU via UART
# This will signal MCU to start the transmission
s.write(b's')  # Assuming 's' is encoded as bytes


for i in range(8):
    x = s.readline()
    print(x.decode())
    data.append(int(x.decode()))
       
# the encode() and decode() function are needed to convert string to bytes
# because pyserial library functions work with type "bytes"


#close the port
print("Closing: " + s.name)
s.close()

#plot the data
x = []
y = []
for i in range(8):
    rad = math.radians(i*45) 
    x.append(data[i]*math.cos(rad))
    y.append(data[i]*math.sin(rad))
    print(rad)

plt.plot(x, y)
plt.xlabel('x(mm)')
plt.ylabel('y(mm)')
plt.title('x vs y')
plt.show()
