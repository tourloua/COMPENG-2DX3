// COMPENG 2DX3 Studio 5 Code Template

//  Written by Ama Simons
//  January 30, 2020
//  Last Update: Feb 8, 2024 by Dr. Shahrukh Athar, 
//	This code provides a base upon which you should develop the two experiments in Studio 5

#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "Systick.h"
#include "PLL.h"

void PortM_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTM_DIR_R = 0b00000000;       								      // Enable PM0 and PM1 as inputs 
  GPIO_PORTM_DEN_R = 0b00001111;														// Enable PM0 and PM1 as digital pins
	return;
}

void PortL_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R10;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R10) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTL_DIR_R = 0b00001111;       								      // Enable PM0 and PM1 as inputs 
  GPIO_PORTL_DEN_R = 0b00001111;														// Enable PM0 and PM1 as digital pins
	return;
}

void PortH_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R7;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R7) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTH_DIR_R = 0b00001111;       								      // Enable PM0 and PM1 as inputs 
  GPIO_PORTH_DEN_R = 0b00001111;														// Enable PM0 and PM1 as digital pins										
	return;
}

void PortA_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R0;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R0) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTA_DIR_R = 0b00000000;       								      // Enable PM0 and PM1 as inputs 
  GPIO_PORTA_DEN_R = 0b00001111;														// Enable PM0 and PM1 as digital pins
	return;
}

void PortN_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;                 // Activate the clock for Port N
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R12) == 0){};				// Allow time for clock to stabilize
		
	GPIO_PORTN_DIR_R=0b00000011;															// Enable PN0 and PN1 as outputs													
	GPIO_PORTN_DEN_R=0b00000011;															// Enable PN0 and PN1 as digital pins
	 
	return;
}

void milestone2(void) {
		uint32_t delay = 50;
		int rotation=0;
	  uint32_t rotation_flag=0;
		while (1) {
			if ((GPIO_PORTM_DATA_R & 0b00000001) == 0b1) {
				GPIO_PORTL_DATA_R ^= 0b00000001;
				while((GPIO_PORTM_DATA_R & 0b00000001) == 0b1) {};
			}
				
			if ((GPIO_PORTM_DATA_R & 0b00000010) == 0b10) {
				GPIO_PORTL_DATA_R ^= 0b00000010;
				while((GPIO_PORTM_DATA_R & 0b00000010) == 0b10) {};
			}

			if ((GPIO_PORTM_DATA_R & 0b00000100) == 0b100) {
				GPIO_PORTL_DATA_R ^= 0b00000100;
				while((GPIO_PORTM_DATA_R & 0b00000100) == 0b100) {};
			}
			
			if((GPIO_PORTM_DATA_R & 0b00001000) == 0b1000) {
				while(rotation!=0){
					GPIO_PORTH_DATA_R = 0b00000011;
					SysTick_Wait10us(delay);											// What if we want to reduce the delay between steps to be less than 10 ms?
					GPIO_PORTH_DATA_R = 0b00001001;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00001100;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00000110;
					SysTick_Wait10us(delay);
					rotation++;
					if (rotation==513){
						rotation=0;
					}
				}
				GPIO_PORTL_DATA_R = GPIO_PORTL_DATA_R & 0b11111110;
			}

			if ((GPIO_PORTL_DATA_R & 0b00000001)== 0b00000001){
				if ((GPIO_PORTL_DATA_R & 0b00000010) == 0b00000010){
					GPIO_PORTH_DATA_R = 0b00000011;
					SysTick_Wait10us(delay);											// What if we want to reduce the delay between steps to be less than 10 ms?
					GPIO_PORTH_DATA_R = 0b00000110;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00001100;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00001001;
					SysTick_Wait10us(delay);
					if (rotation==0){
						rotation=513;
					}
					rotation=rotation-1;
				}
				else{	
					GPIO_PORTH_DATA_R = 0b00000011;
					SysTick_Wait10us(delay);											// What if we want to reduce the delay between steps to be less than 10 ms?
					GPIO_PORTH_DATA_R = 0b00001001;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00001100;
					SysTick_Wait10us(delay);
					GPIO_PORTH_DATA_R = 0b00000110;
					SysTick_Wait10us(delay);
					if (rotation==512){
						rotation=0;
					}					
					rotation=rotation+1;
				}
				if ((GPIO_PORTL_DATA_R & 0b00000100)==0b00000100){
					rotation_flag=1;
				}
				else{
					rotation_flag=0;
				}
				if (rotation_flag==1){
					if (rotation%16==0){
						GPIO_PORTL_DATA_R = GPIO_PORTL_DATA_R | 0b00001000;
						SysTick_Wait10us(25);
						GPIO_PORTL_DATA_R = GPIO_PORTL_DATA_R & 0b11110111;
					}
				}
				else{
					if (rotation%64==0){
						GPIO_PORTL_DATA_R = GPIO_PORTL_DATA_R | 0b00001000;
						SysTick_Wait10us(25);
						GPIO_PORTL_DATA_R = GPIO_PORTL_DATA_R & 0b11110111;					
					}
				}

		}
	}
}


int main(void){
	
	PortM_Init();
	PortL_Init();
	PortH_Init();
//	PortA_Init();
//	PortN_Init();
	SysTick_Init();
  GPIO_PORTL_DATA_R = 0b00000000;


	// Turn off LEDs at reset


	milestone2();
		
	
}