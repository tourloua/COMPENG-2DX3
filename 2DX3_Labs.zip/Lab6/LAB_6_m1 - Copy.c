#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "Systick.h"
#include "PLL.h"

void PortM_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;                 // Activate the clock for Port M
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTM_DIR_R = 0b00000000;       								      // Enable PM0-PM3 as inputs 
  GPIO_PORTM_DEN_R = 0b00001111;														// Enable PM0-PM3 as GPIO
	return;
}

void PortL_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R10;                 // Activate the clock for Port L
	while((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R10) == 0){};      // Allow time for clock to stabilize
		
	GPIO_PORTL_DIR_R = 0b00001111;       								      // Enable PL0-PL3 as inputs  
  GPIO_PORTL_DEN_R = 0b00001111;														// Enable PL0 and PL1 as GPIO
	return;
}



void milestone1(void) {
		while (1) {
			if (GPIO_PORTM_DATA_R ==0x01 ) {
				GPIO_PORTL_DATA_R ^= 0b00000001;
				while((GPIO_PORTM_DATA_R & 0b00000001) == 0) {};//This helps the program register that a button has been pressed
				}
				
			if (GPIO_PORTM_DATA_R ==0x02 ) {
				GPIO_PORTL_DATA_R ^= 0b00000010;
				while((GPIO_PORTM_DATA_R & 0b00000010) == 0) {};
				}

			if (GPIO_PORTM_DATA_R ==0x04 ) {
				GPIO_PORTL_DATA_R ^= 0b00000100;
				while((GPIO_PORTM_DATA_R & 0b00000100) == 0) {};
				}
			
			if(GPIO_PORTM_DATA_R ==0x08 ) {
				GPIO_PORTL_DATA_R ^= 0b00001000;				
				while((GPIO_PORTM_DATA_R & 0b00001000) == 0) {};
				}
		}
}


int main(void){
	PortM_Init();
	PortL_Init();
	SysTick_Init();
	
	// Turn off LEDs at reset
	GPIO_PORTL_DATA_R = 0b00000000;
	GPIO_PORTN_DATA_R = 0b00000000;

	milestone1();

}