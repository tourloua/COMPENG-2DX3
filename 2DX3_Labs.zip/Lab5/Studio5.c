#include <stdint.h>
#include "tm4c1294ncpdt.h"
#include "PLL.h"
#include "SysTick.h"

void PortE_Init(void)
{
    // activate the clock for Port E
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R4;
    // allow time for clock to stabilize
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R4) == 0)
    {
    };

    // Enable ports E0 - E3 for output
    GPIO_PORTE_DEN_R = 0b00001111;
    GPIO_PORTE_DIR_R = 0b00001111;

    // set pull-up resistors for the input
    GPIO_PORTE_PUR_R = 0b00001111;

    return;
}

void PortM_Init(void)
{
    // activate the clock for Port M
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R11;
    // allow time for clock to stabilize
    while ((SYSCTL_PRGPIO_R & SYSCTL_PRGPIO_R11) == 0)
    {
    };

    // Enable ports M0 - M3 for input
    GPIO_PORTM_DIR_R = 0b00000000;
    GPIO_PORTM_DEN_R = 0b00001111;

    // set pull-up resistors
    GPIO_PORTM_PUR_R = 0b00001111;
    return;
}
void PortN_Init(void){
	SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R12;                 // Activate the clock for Port N
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R12) == 0){};				// Allow time for clock to stabilize
		
	GPIO_PORTN_DIR_R=0b00000011;															// Enable PN0 and PN1 as outputs													
	GPIO_PORTN_DEN_R=0b00000011;															// Enable PN0 and PN1 as digital pins
	return;
}

//Enable LED D3, D4. Remember D3 is connected to PF4 and D4 is connected to PF0
void PortF_Init(void){
  SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R5;                 	// Activate the clock for Port F
	while((SYSCTL_PRGPIO_R&SYSCTL_PRGPIO_R5) == 0){};					// Allow time for clock to stabilize
		
	GPIO_PORTF_DIR_R=0b00010001;															// Enable PF0 and PF4 as outputs
	GPIO_PORTF_DEN_R=0b00010001;															// Enable PF0 and PF4 as digital pins
	return;
}

int main(void)
{
    PLL_Init();
    SysTick_Init();

    PortE_Init();
    PortM_Init();
		PortF_Init();
	  PortN_Init();


    uint8_t binary_key_value;
    uint8_t output;
    uint8_t input;
    uint8_t input_output;

    while (1)
    {

        // Row 1
        {
            // drive low for scanning
            GPIO_PORTE_DIR_R = 0b00000001;
            GPIO_PORTE_DATA_R = 0b00000000;

            output = 0b0001;

            // Column 1 - Button 1
            while ((GPIO_PORTM_DATA_R & 0b00000001) == 0)
            {
                binary_key_value = 1;
                input = 0b0001;
                input_output = 0b00010001;
							  GPIO_PORTN_DATA_R = 0b00000010;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;

            // Column 2 - Button 2
            while ((GPIO_PORTM_DATA_R & 0b00000010) == 0)
            {
                binary_key_value = 2;
                input = 0b0010;
                input_output = 0b00100001;
								GPIO_PORTN_DATA_R = 0b00000001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 3 - Button 3
            while ((GPIO_PORTM_DATA_R & 0b00000100) == 0)
            {
                binary_key_value = 3;
                input = 0b0100;
                input_output = 0b01000001;
							  GPIO_PORTN_DATA_R = 0b00000011;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 4 - Button 4
            while ((GPIO_PORTM_DATA_R & 0b00001000) == 0)
            {
                binary_key_value = 10;
                input = 0b1000;
                input_output = 0b10000001;
							  GPIO_PORTN_DATA_R = 0b00000001;
						   	GPIO_PORTF_DATA_R = 0b00000001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000; 
				}

        // Row 2
        {
            GPIO_PORTE_DIR_R = 0b00000010; // Drive Row 2
            GPIO_PORTE_DATA_R = 0b00000000;

            output = 0b0010;

            // Column 1 - Button 5
            while ((GPIO_PORTM_DATA_R & 0b00000001) == 0)
            {
                // 4
                binary_key_value = 4;
                input = 0b0001;
                input_output = 0b00010010;
						   	GPIO_PORTF_DATA_R = 0b00010000;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 2 - Button 6
            while ((GPIO_PORTM_DATA_R & 0b00000010) == 0)
            {
                // 5
                binary_key_value = 5;
                input = 0b0010;
                input_output = 0b00100010;
						  	GPIO_PORTF_DATA_R = 0b00010000;
						  	GPIO_PORTN_DATA_R = 0b00000010;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;						

            // Column 3 - Button 7
            while ((GPIO_PORTM_DATA_R & 0b00000100) == 0)
            {
                // 6
                binary_key_value = 6;
                input = 0b0100;
                input_output = 0b01000010;
						  	GPIO_PORTF_DATA_R = 0b00010000;
							  GPIO_PORTN_DATA_R = 0b00000001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;						

            // Column 4 - Button 8
            while ((GPIO_PORTM_DATA_R & 0b00001000) == 0)
            {
                // B
                binary_key_value = 11;
                input = 0b1000;
                input_output = 0b10000010;
						  	GPIO_PORTF_DATA_R = 0b00000001;
							  GPIO_PORTN_DATA_R = 0b00000011;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;						
        }

        // Row 3
        {
            GPIO_PORTE_DIR_R = 0b00000100; // To drive you use the data direction register
            GPIO_PORTE_DATA_R = 0b00000000;

            output = 0b0100;

            // Column 1 - Button 9
            while ((GPIO_PORTM_DATA_R & 0b00000001) == 0)
            {
                // 7
                binary_key_value = 7;
                input = 0b0001;
                input_output = 0b00010100;
							  GPIO_PORTF_DATA_R = 0b00010000;
							  GPIO_PORTN_DATA_R = 0b00000011;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 2 - Button 10
            while ((GPIO_PORTM_DATA_R & 0b00000010) == 0)
            {
                // 8
                binary_key_value = 8;
                input = 0b0010;
                input_output = 0b00100100;
						   	GPIO_PORTF_DATA_R = 0b00000001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 3 - Button 11
            while ((GPIO_PORTM_DATA_R & 0b00000100) == 0)
            {
                // 9
                binary_key_value = 9;
                input = 0b0100;
                input_output = 0b01000100;
						  	GPIO_PORTF_DATA_R = 0b00000001;
							  GPIO_PORTN_DATA_R = 0b00000010;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 4 - Button 12
            while ((GPIO_PORTM_DATA_R & 0b00001000) == 0)
            {
                // C
                binary_key_value = 12;
                input = 0b1000;
                input_output = 0b10000100;
							  GPIO_PORTF_DATA_R = 0b00010001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;						
        }

        // Row 4
        {
            GPIO_PORTE_DIR_R = 0b00001000; // To drive you use the data direction register
            GPIO_PORTE_DATA_R = 0b00000000;

            output = 0b1000;

            // Column 1 - Button 13
            while ((GPIO_PORTM_DATA_R & 0b00000001) == 0)
            {
                //*
                binary_key_value = 14;
                input = 0b0001;
                input_output = 0b00011000;
					  		GPIO_PORTF_DATA_R = 0b00010001;
							  GPIO_PORTN_DATA_R = 0b00000001;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 2 - Button 14
            while ((GPIO_PORTM_DATA_R & 0b00000010) == 0)
            {
                // 0
                binary_key_value = 0;
                input = 0b0010;
                input_output = 0b00101000;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
						
            // Column 3 - Button 15
            while ((GPIO_PORTM_DATA_R & 0b00000100) == 0)
            {
                // #
                binary_key_value = 15;
                input = 0b0100;
                input_output = 0b01001000;
						  	GPIO_PORTF_DATA_R = 0b00010001;
							  GPIO_PORTN_DATA_R = 0b00000011;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;
            // Column 4 - Button 16
            while ((GPIO_PORTM_DATA_R & 0b00001000) == 0)
            {
                // D
                binary_key_value = 13;
                input = 0b1000;
                input_output = 0b10001000;
					  		GPIO_PORTF_DATA_R = 0b00010001;
							  GPIO_PORTN_DATA_R = 0b00000010;
            }
						GPIO_PORTN_DATA_R = 0b00000000;
						GPIO_PORTF_DATA_R = 0b00000000;						
        }
    }
}